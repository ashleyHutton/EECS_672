var searchData=
[
  ['caps',['Caps',['../classBasicShape.html#a9f86f05592b8ce6fac807218405cb567',1,'BasicShape']]]
];
